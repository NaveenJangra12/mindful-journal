import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { JournalProvider } from './context/JournalContext';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Entries from './pages/Entries';
import NewEntry from './pages/NewEntry';
import EditEntry from './pages/EditEntry';
import EntryDetail from './pages/EntryDetail';
import Analytics from './pages/Analytics';

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--accent)',
      fontFamily: 'var(--font-display)',
      fontSize: '1.5rem'
    }}>
      ◈
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
};

const PublicRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return null;
  return user ? <Navigate to="/dashboard" replace /> : children;
};

const AppLayout = ({ children }) => (
  <>
    <Navbar />
    <main>{children}</main>
  </>
);

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <Routes>
        <Route path="/login" element={
          <PublicRoute><Login /></PublicRoute>
        } />
        <Route path="/register" element={
          <PublicRoute><Register /></PublicRoute>
        } />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <JournalProvider>
              <AppLayout><Dashboard /></AppLayout>
            </JournalProvider>
          </ProtectedRoute>
        } />
        <Route path="/entries" element={
          <ProtectedRoute>
            <JournalProvider>
              <AppLayout><Entries /></AppLayout>
            </JournalProvider>
          </ProtectedRoute>
        } />
        <Route path="/new-entry" element={
          <ProtectedRoute>
            <JournalProvider>
              <AppLayout><NewEntry /></AppLayout>
            </JournalProvider>
          </ProtectedRoute>
        } />
        <Route path="/edit/:id" element={
          <ProtectedRoute>
            <JournalProvider>
              <AppLayout><EditEntry /></AppLayout>
            </JournalProvider>
          </ProtectedRoute>
        } />
        <Route path="/entry/:id" element={
          <ProtectedRoute>
            <JournalProvider>
              <AppLayout><EntryDetail /></AppLayout>
            </JournalProvider>
          </ProtectedRoute>
        } />
        <Route path="/analytics" element={
          <ProtectedRoute>
            <JournalProvider>
              <AppLayout><Analytics /></AppLayout>
            </JournalProvider>
          </ProtectedRoute>
        } />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </AuthProvider>
  </BrowserRouter>
);

export default App;
