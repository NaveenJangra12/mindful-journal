import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import SentimentBadge from './SentimentBadge';
import './EntryCard.css';

const EntryCard = ({ entry, onDelete }) => {
  const preview = entry.content.length > 120
    ? entry.content.substring(0, 120) + '...'
    : entry.content;

  return (
    <div className="entry-card fade-in">
      <div className="entry-card__header">
        <div className="entry-card__meta">
          <span className="entry-card__mood">{entry.mood}</span>
          <span className="entry-card__date">
            {format(new Date(entry.createdAt), 'MMM d, yyyy')}
          </span>
        </div>
        {entry.sentiment && (
          <SentimentBadge label={entry.sentiment.label} score={entry.sentiment.score} />
        )}
      </div>

      <h3 className="entry-card__title">{entry.title}</h3>
      <p className="entry-card__preview">{preview}</p>

      <div className="entry-card__footer">
        <div className="entry-card__stats">
          <span>{entry.sentiment?.wordCount || 0} words</span>
        </div>
        <div className="entry-card__actions">
          <Link to={`/entry/${entry.id}`} className="entry-btn entry-btn--view">
            Read
          </Link>
          <Link to={`/edit/${entry.id}`} className="entry-btn entry-btn--edit">
            Edit
          </Link>
          <button
            className="entry-btn entry-btn--delete"
            onClick={() => onDelete && onDelete(entry.id)}
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default EntryCard;
