import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar">
      <Link to="/dashboard" className="navbar-brand">
        <span className="brand-icon">◈</span>
        <span className="brand-text">Mindful Journal</span>
      </Link>

      <div className={`navbar-links ${menuOpen ? 'open' : ''}`}>
        <Link to="/dashboard" className={`nav-link ${isActive('/dashboard') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>
          Dashboard
        </Link>
        <Link to="/entries" className={`nav-link ${isActive('/entries') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>
          Entries
        </Link>
        <Link to="/new-entry" className={`nav-link ${isActive('/new-entry') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>
          New Entry
        </Link>
        <Link to="/analytics" className={`nav-link ${isActive('/analytics') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>
          Analytics
        </Link>
      </div>

      <div className="navbar-right">
        {user && (
          <div className="user-menu">
            <span className="user-name">{user.name || user.email.split('@')[0]}</span>
            <button className="logout-btn" onClick={handleLogout}>Sign out</button>
          </div>
        )}
        <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
          <span /><span /><span />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
