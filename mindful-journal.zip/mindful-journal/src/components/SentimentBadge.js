import React from 'react';
import { getSentimentColor, getSentimentBg, getSentimentEmoji } from '../utils/sentiment';
import './SentimentBadge.css';

const SentimentBadge = ({ label, score, size = 'sm' }) => {
  if (!label) return null;
  return (
    <span
      className={`sentiment-badge sentiment-badge--${size}`}
      style={{
        color: getSentimentColor(label),
        background: getSentimentBg(label),
        borderColor: getSentimentColor(label) + '33',
      }}
    >
      <span className="sentiment-icon">{getSentimentEmoji(label)}</span>
      <span className="sentiment-label">{label}</span>
      {score !== undefined && size !== 'sm' && (
        <span className="sentiment-score">{score > 0 ? '+' : ''}{score}</span>
      )}
    </span>
  );
};

export default SentimentBadge;
