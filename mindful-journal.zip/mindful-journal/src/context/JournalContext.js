import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { analyzeSentiment } from '../utils/sentiment';

const JournalContext = createContext(null);

export const JournalProvider = ({ children }) => {
  const { user } = useAuth();
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    if (user) {
      const stored = JSON.parse(localStorage.getItem(`mj_entries_${user.id}`) || '[]');
      setEntries(stored);
    } else {
      setEntries([]);
    }
  }, [user]);

  const saveEntries = (updated) => {
    setEntries(updated);
    if (user) localStorage.setItem(`mj_entries_${user.id}`, JSON.stringify(updated));
  };

  const addEntry = (title, content, mood) => {
    const sentiment = analyzeSentiment(content);
    const entry = {
      id: Date.now().toString(),
      title,
      content,
      mood,
      sentiment,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveEntries([entry, ...entries]);
    return entry;
  };

  const updateEntry = (id, title, content, mood) => {
    const sentiment = analyzeSentiment(content);
    const updated = entries.map(e =>
      e.id === id ? { ...e, title, content, mood, sentiment, updatedAt: new Date().toISOString() } : e
    );
    saveEntries(updated);
  };

  const deleteEntry = (id) => {
    saveEntries(entries.filter(e => e.id !== id));
  };

  const getEntry = (id) => entries.find(e => e.id === id);

  return (
    <JournalContext.Provider value={{ entries, addEntry, updateEntry, deleteEntry, getEntry }}>
      {children}
    </JournalContext.Provider>
  );
};

export const useJournal = () => useContext(JournalContext);
