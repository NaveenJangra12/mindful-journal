import React, { useMemo } from 'react';
import { format, subDays, parseISO } from 'date-fns';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid
} from 'recharts';
import { useJournal } from '../context/JournalContext';
import './Analytics.css';

const COLORS = {
  positive: '#4ade80',
  neutral: '#94a3b8',
  negative: '#f87171',
};

const Analytics = () => {
  const { entries } = useJournal();

  const last30Days = useMemo(() => {
    const days = [];
    for (let i = 29; i >= 0; i--) {
      const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
      const dayEntries = entries.filter(e =>
        format(parseISO(e.createdAt), 'yyyy-MM-dd') === date
      );
      const avgScore = dayEntries.length > 0
        ? dayEntries.reduce((sum, e) => sum + (e.sentiment?.score || 0), 0) / dayEntries.length
        : null;
      days.push({
        date: format(subDays(new Date(), i), 'MMM d'),
        score: avgScore !== null ? Math.round(avgScore * 100) / 100 : null,
        count: dayEntries.length,
      });
    }
    return days;
  }, [entries]);

  const pieData = useMemo(() => {
    const counts = { positive: 0, neutral: 0, negative: 0 };
    entries.forEach(e => {
      const label = e.sentiment?.label;
      if (label && counts[label] !== undefined) counts[label]++;
    });
    return Object.entries(counts)
      .filter(([, v]) => v > 0)
      .map(([name, value]) => ({ name, value }));
  }, [entries]);

  const weeklyData = useMemo(() => {
    const weeks = {};
    entries.forEach(e => {
      const week = format(parseISO(e.createdAt), 'MMM d');
      if (!weeks[week]) weeks[week] = { date: week, positive: 0, neutral: 0, negative: 0 };
      const label = e.sentiment?.label;
      if (label) weeks[week][label]++;
    });
    return Object.values(weeks).slice(-10);
  }, [entries]);

  const avgScore = useMemo(() => {
    const scored = entries.filter(e => e.sentiment?.score !== undefined);
    if (!scored.length) return 0;
    return Math.round(scored.reduce((s, e) => s + e.sentiment.score, 0) / scored.length * 100) / 100;
  }, [entries]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="chart-tooltip">
        <div className="tooltip-label">{label}</div>
        {payload.map((p, i) => (
          <div key={i} className="tooltip-row" style={{ color: p.color || p.fill }}>
            {p.name}: <strong>{p.value}</strong>
          </div>
        ))}
      </div>
    );
  };

  if (entries.length === 0) {
    return (
      <div className="analytics-page page-wrapper">
        <h1 className="analytics-title">Analytics</h1>
        <div className="empty-state">
          <div className="empty-icon">◈</div>
          <p>Write some entries to see your analytics.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="analytics-page page-wrapper">
      <div className="analytics-header fade-in">
        <h1 className="analytics-title">Analytics</h1>
        <p className="analytics-subtitle">Your emotional patterns over time</p>
      </div>

      <div className="analytics-stats fade-in">
        <div className="a-stat">
          <span className="a-stat-value">{entries.length}</span>
          <span className="a-stat-label">Total entries</span>
        </div>
        <div className="a-stat">
          <span className="a-stat-value" style={{ color: avgScore >= 0 ? 'var(--positive)' : 'var(--negative)' }}>
            {avgScore > 0 ? '+' : ''}{avgScore}
          </span>
          <span className="a-stat-label">Avg. sentiment score</span>
        </div>
        <div className="a-stat">
          <span className="a-stat-value" style={{ color: 'var(--positive)' }}>
            {entries.filter(e => e.sentiment?.label === 'positive').length}
          </span>
          <span className="a-stat-label">Positive entries</span>
        </div>
        <div className="a-stat">
          <span className="a-stat-value" style={{ color: 'var(--negative)' }}>
            {entries.filter(e => e.sentiment?.label === 'negative').length}
          </span>
          <span className="a-stat-label">Difficult entries</span>
        </div>
      </div>

      <div className="chart-card fade-in" style={{ animationDelay: '0.1s' }}>
        <h2 className="chart-title">Sentiment score over time (30 days)</h2>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={last30Days} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis
              dataKey="date"
              tick={{ fill: '#4a4f66', fontSize: 11 }}
              tickLine={false}
              interval={4}
            />
            <YAxis
              domain={[-1, 1]}
              tick={{ fill: '#4a4f66', fontSize: 11 }}
              tickLine={false}
              axisLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone"
              dataKey="score"
              stroke="#c8a96e"
              strokeWidth={2}
              dot={false}
              connectNulls
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="charts-row">
        <div className="chart-card fade-in" style={{ animationDelay: '0.15s' }}>
          <h2 className="chart-title">Mood distribution</h2>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={3}
                dataKey="value"
              >
                {pieData.map((entry) => (
                  <Cell key={entry.name} fill={COLORS[entry.name]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pie-legend">
            {pieData.map(d => (
              <div key={d.name} className="pie-legend-item">
                <span className="pie-dot" style={{ background: COLORS[d.name] }} />
                <span className="pie-legend-label">{d.name}</span>
                <span className="pie-legend-val">{d.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="chart-card fade-in" style={{ animationDelay: '0.2s' }}>
          <h2 className="chart-title">Entries by sentiment</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#4a4f66', fontSize: 11 }} tickLine={false} />
              <YAxis tick={{ fill: '#4a4f66', fontSize: 11 }} tickLine={false} axisLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="positive" stackId="a" fill="#4ade80" radius={[0, 0, 0, 0]} />
              <Bar dataKey="neutral" stackId="a" fill="#94a3b8" />
              <Bar dataKey="negative" stackId="a" fill="#f87171" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
