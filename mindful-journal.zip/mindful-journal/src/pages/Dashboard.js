import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { useAuth } from '../context/AuthContext';
import { useJournal } from '../context/JournalContext';
import SentimentBadge from '../components/SentimentBadge';
import './Dashboard.css';

const Dashboard = () => {
  const { user } = useAuth();
  const { entries } = useJournal();

  const stats = useMemo(() => {
    const total = entries.length;
    const positive = entries.filter(e => e.sentiment?.label === 'positive').length;
    const negative = entries.filter(e => e.sentiment?.label === 'negative').length;
    const neutral = entries.filter(e => e.sentiment?.label === 'neutral').length;
    const streak = calculateStreak(entries);
    return { total, positive, negative, neutral, streak };
  }, [entries]);

  const recentEntries = entries.slice(0, 3);

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const name = user?.name || user?.email?.split('@')[0] || 'there';

  return (
    <div className="dashboard page-wrapper">
      <div className="dashboard-hero fade-in">
        <div>
          <h1 className="dashboard-greeting">
            {greeting()}, <span className="highlight">{name}</span>
          </h1>
          <p className="dashboard-date">
            {format(new Date(), 'EEEE, MMMM d, yyyy')}
          </p>
        </div>
        <Link to="/new-entry" className="new-entry-cta">
          <span>+</span> New Entry
        </Link>
      </div>

      <div className="stats-grid">
        <div className="stat-card fade-in" style={{ animationDelay: '0.05s' }}>
          <span className="stat-value">{stats.total}</span>
          <span className="stat-label">Total entries</span>
        </div>
        <div className="stat-card stat-card--positive fade-in" style={{ animationDelay: '0.1s' }}>
          <span className="stat-value">{stats.positive}</span>
          <span className="stat-label">Positive days</span>
        </div>
        <div className="stat-card stat-card--negative fade-in" style={{ animationDelay: '0.15s' }}>
          <span className="stat-value">{stats.negative}</span>
          <span className="stat-label">Difficult days</span>
        </div>
        <div className="stat-card fade-in" style={{ animationDelay: '0.2s' }}>
          <span className="stat-value">{stats.streak}</span>
          <span className="stat-label">Day streak</span>
        </div>
      </div>

      <div className="dashboard-sections">
        <section className="recent-section">
          <div className="section-header">
            <h2 className="section-title">Recent entries</h2>
            <Link to="/entries" className="section-link">View all →</Link>
          </div>

          {recentEntries.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">◈</div>
              <p>Your journal is empty.</p>
              <Link to="/new-entry" className="empty-cta">Write your first entry</Link>
            </div>
          ) : (
            <div className="recent-list">
              {recentEntries.map((entry, i) => (
                <Link
                  key={entry.id}
                  to={`/entry/${entry.id}`}
                  className="recent-item fade-in"
                  style={{ animationDelay: `${i * 0.08}s` }}
                >
                  <div className="recent-item__left">
                    <span className="recent-mood">{entry.mood}</span>
                    <div>
                      <div className="recent-title">{entry.title}</div>
                      <div className="recent-date">
                        {format(new Date(entry.createdAt), 'MMM d')}
                      </div>
                    </div>
                  </div>
                  {entry.sentiment && (
                    <SentimentBadge label={entry.sentiment.label} />
                  )}
                </Link>
              ))}
            </div>
          )}
        </section>

        <section className="mood-summary">
          <h2 className="section-title">Mood overview</h2>
          <div className="mood-bars">
            <MoodBar label="Positive" count={stats.positive} total={stats.total} color="var(--positive)" />
            <MoodBar label="Neutral" count={stats.neutral} total={stats.total} color="var(--neutral)" />
            <MoodBar label="Difficult" count={stats.negative} total={stats.total} color="var(--negative)" />
          </div>
          <Link to="/analytics" className="analytics-link">
            View detailed analytics →
          </Link>
        </section>
      </div>
    </div>
  );
};

const MoodBar = ({ label, count, total, color }) => {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="mood-bar">
      <div className="mood-bar__header">
        <span className="mood-bar__label">{label}</span>
        <span className="mood-bar__count">{count} <span style={{ color: 'var(--text-muted)' }}>({pct}%)</span></span>
      </div>
      <div className="mood-bar__track">
        <div
          className="mood-bar__fill"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
    </div>
  );
};

const calculateStreak = (entries) => {
  if (!entries.length) return 0;
  const dates = [...new Set(entries.map(e =>
    format(new Date(e.createdAt), 'yyyy-MM-dd')
  ))].sort().reverse();

  let streak = 0;
  let current = new Date();

  for (const date of dates) {
    const d = new Date(date);
    const diff = Math.floor((current - d) / (1000 * 60 * 60 * 24));
    if (diff <= 1) { streak++; current = d; }
    else break;
  }
  return streak;
};

export default Dashboard;
