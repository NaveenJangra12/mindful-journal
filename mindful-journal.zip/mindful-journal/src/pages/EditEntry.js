import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useJournal } from '../context/JournalContext';
import { analyzeSentiment, getSentimentColor, getSentimentEmoji } from '../utils/sentiment';
import './EntryForm.css';

const MOODS = ['😊','😔','😤','😌','🎉','😟','🌿','✨','😐','💪','🥺','😴'];

const EditEntry = () => {
  const { id } = useParams();
  const { getEntry, updateEntry } = useJournal();
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: '', content: '', mood: '😊' });
  const [preview, setPreview] = useState(null);
  const [saving, setSaving] = useState(false);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const entry = getEntry(id);
    if (!entry) { setNotFound(true); return; }
    setForm({ title: entry.title, content: entry.content, mood: entry.mood });
  }, [id, getEntry]);

  useEffect(() => {
    if (form.content.trim().length > 10) {
      setPreview(analyzeSentiment(form.content));
    } else {
      setPreview(null);
    }
  }, [form.content]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.content.trim()) return;
    setSaving(true);
    setTimeout(() => {
      updateEntry(id, form.title, form.content, form.mood);
      navigate(`/entry/${id}`);
    }, 400);
  };

  if (notFound) {
    return (
      <div className="page-wrapper">
        <div className="empty-state">
          <div className="empty-icon">◈</div>
          <p>Entry not found.</p>
          <button className="cancel-btn" onClick={() => navigate('/entries')}>
            Back to entries
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="entry-form-page page-wrapper">
      <div className="entry-form-header fade-in">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>
        <h1 className="entry-form-title">Edit entry</h1>
      </div>

      <div className="entry-form-layout">
        <form className="entry-form fade-in" onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Title</label>
            <input
              type="text"
              className="form-input"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Mood</label>
            <div className="mood-picker">
              {MOODS.map(m => (
                <button
                  key={m}
                  type="button"
                  className={`mood-option ${form.mood === m ? 'selected' : ''}`}
                  onClick={() => setForm({ ...form, mood: m })}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">
              Your thoughts
              <span className="word-count">{form.content.split(/\s+/).filter(Boolean).length} words</span>
            </label>
            <textarea
              className="form-textarea"
              value={form.content}
              onChange={e => setForm({ ...form, content: e.target.value })}
              rows={14}
              required
            />
          </div>

          <div className="form-actions">
            <button type="button" className="cancel-btn" onClick={() => navigate(-1)}>
              Cancel
            </button>
            <button type="submit" className="save-btn" disabled={saving}>
              {saving ? 'Saving...' : 'Update entry'}
            </button>
          </div>
        </form>

        <aside className="entry-sidebar fade-in" style={{ animationDelay: '0.1s' }}>
          <div className="sidebar-card">
            <h3 className="sidebar-title">Live sentiment preview</h3>
            {preview ? (
              <div className="sentiment-preview">
                <div className="sentiment-preview__badge" style={{ color: getSentimentColor(preview.label) }}>
                  <span className="sentiment-preview__icon">{getSentimentEmoji(preview.label)}</span>
                  <span className="sentiment-preview__label">{preview.label}</span>
                </div>
                <div className="sentiment-preview__score">Score: <strong>{preview.score > 0 ? '+' : ''}{preview.score}</strong></div>
                <div className="sentiment-preview__confidence">Confidence: <strong>{Math.round(preview.confidence * 100)}%</strong></div>
                <div className="sentiment-preview__breakdown">
                  <span className="pos-count">✦ {preview.positiveCount} positive</span>
                  <span className="neg-count">◆ {preview.negativeCount} negative</span>
                </div>
              </div>
            ) : (
              <p className="sidebar-hint">Keep writing to see your updated sentiment analysis.</p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
};

export default EditEntry;
