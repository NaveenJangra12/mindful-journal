import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useJournal } from '../context/JournalContext';
import EntryCard from '../components/EntryCard';
import './Entries.css';

const FILTERS = ['all', 'positive', 'neutral', 'negative'];

const Entries = () => {
  const { entries, deleteEntry } = useJournal();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filtered = entries.filter(e => {
    const matchFilter = filter === 'all' || e.sentiment?.label === filter;
    const matchSearch = !search ||
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      e.content.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const handleDelete = (id) => {
    if (window.confirm('Delete this entry? This cannot be undone.')) {
      deleteEntry(id);
    }
  };

  return (
    <div className="entries-page page-wrapper">
      <div className="entries-header fade-in">
        <div>
          <h1 className="entries-title">Your entries</h1>
          <p className="entries-count">{entries.length} total</p>
        </div>
        <Link to="/new-entry" className="new-entry-btn">+ New entry</Link>
      </div>

      <div className="entries-controls fade-in">
        <input
          type="text"
          className="search-input"
          placeholder="Search entries..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="filter-tabs">
          {FILTERS.map(f => (
            <button
              key={f}
              className={`filter-tab ${filter === f ? 'active' : ''}`}
              onClick={() => setFilter(f)}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state fade-in">
          <div className="empty-icon">◈</div>
          {entries.length === 0 ? (
            <>
              <p>No entries yet. Start your journey.</p>
              <Link to="/new-entry" className="empty-cta">Write your first entry</Link>
            </>
          ) : (
            <p>No entries match your search or filter.</p>
          )}
        </div>
      ) : (
        <div className="entries-grid">
          {filtered.map((entry, i) => (
            <div key={entry.id} style={{ animationDelay: `${i * 0.04}s` }}>
              <EntryCard entry={entry} onDelete={handleDelete} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Entries;
