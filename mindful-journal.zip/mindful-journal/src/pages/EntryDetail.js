import React from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { format } from 'date-fns';
import { useJournal } from '../context/JournalContext';
import { getSentimentColor, getSentimentBg, getSentimentEmoji } from '../utils/sentiment';
import './EntryDetail.css';

const EntryDetail = () => {
  const { id } = useParams();
  const { getEntry, deleteEntry } = useJournal();
  const navigate = useNavigate();
  const entry = getEntry(id);

  if (!entry) {
    return (
      <div className="page-wrapper">
        <div className="empty-state">
          <div className="empty-icon">◈</div>
          <p>Entry not found.</p>
          <button className="cancel-btn" onClick={() => navigate('/entries')}>Back to entries</button>
        </div>
      </div>
    );
  }

  const handleDelete = () => {
    if (window.confirm('Delete this entry? This cannot be undone.')) {
      deleteEntry(id);
      navigate('/entries');
    }
  };

  const s = entry.sentiment;

  return (
    <div className="entry-detail-page page-wrapper">
      <div className="detail-header fade-in">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>
        <div className="detail-actions">
          <Link to={`/edit/${entry.id}`} className="edit-link">Edit</Link>
          <button className="delete-link" onClick={handleDelete}>Delete</button>
        </div>
      </div>

      <article className="detail-article fade-in">
        <div className="detail-meta">
          <span className="detail-mood">{entry.mood}</span>
          <div>
            <div className="detail-date">
              {format(new Date(entry.createdAt), 'EEEE, MMMM d, yyyy')}
            </div>
            {entry.updatedAt !== entry.createdAt && (
              <div className="detail-updated">
                Updated {format(new Date(entry.updatedAt), 'MMM d, yyyy')}
              </div>
            )}
          </div>
        </div>

        <h1 className="detail-title">{entry.title}</h1>

        <div className="detail-body">
          {entry.content.split('\n').map((para, i) =>
            para.trim() ? <p key={i}>{para}</p> : <br key={i} />
          )}
        </div>
      </article>

      {s && (
        <div className="sentiment-card fade-in" style={{ animationDelay: '0.15s' }}>
          <h2 className="sentiment-card__title">Sentiment Analysis</h2>
          <div className="sentiment-card__grid">
            <div
              className="sentiment-card__result"
              style={{ background: getSentimentBg(s.label), borderColor: getSentimentColor(s.label) + '44' }}
            >
              <span className="result-icon" style={{ color: getSentimentColor(s.label) }}>
                {getSentimentEmoji(s.label)}
              </span>
              <span className="result-label" style={{ color: getSentimentColor(s.label) }}>
                {s.label}
              </span>
            </div>

            <div className="sentiment-metrics">
              <div className="metric">
                <span className="metric-label">Sentiment score</span>
                <span className="metric-value">{s.score > 0 ? '+' : ''}{s.score}</span>
              </div>
              <div className="metric">
                <span className="metric-label">Confidence</span>
                <span className="metric-value">{Math.round(s.confidence * 100)}%</span>
              </div>
              <div className="metric">
                <span className="metric-label">Word count</span>
                <span className="metric-value">{s.wordCount}</span>
              </div>
              <div className="metric">
                <span className="metric-label">Positive signals</span>
                <span className="metric-value" style={{ color: 'var(--positive)' }}>
                  {s.positiveCount}
                </span>
              </div>
              <div className="metric">
                <span className="metric-label">Negative signals</span>
                <span className="metric-value" style={{ color: 'var(--negative)' }}>
                  {s.negativeCount}
                </span>
              </div>
            </div>
          </div>

          <div className="sentiment-bar-wrap">
            <span style={{ color: 'var(--negative)', fontSize: '0.75rem' }}>Negative</span>
            <div className="sentiment-spectrum">
              <div
                className="spectrum-marker"
                style={{ left: `${((s.score + 1) / 2) * 100}%`, background: getSentimentColor(s.label) }}
              />
            </div>
            <span style={{ color: 'var(--positive)', fontSize: '0.75rem' }}>Positive</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default EntryDetail;
