import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useJournal } from '../context/JournalContext';
import { analyzeSentiment, getSentimentColor, getSentimentEmoji } from '../utils/sentiment';
import './EntryForm.css';

const MOODS = ['😊','😔','😤','😌','🎉','😟','🌿','✨','😐','💪','🥺','😴'];

const NewEntry = () => {
  const { addEntry } = useJournal();
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: '', content: '', mood: '😊' });
  const [preview, setPreview] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (form.content.trim().length > 10) {
      const result = analyzeSentiment(form.content);
      setPreview(result);
    } else {
      setPreview(null);
    }
  }, [form.content]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.content.trim()) return;
    setSaving(true);
    setTimeout(() => {
      const entry = addEntry(form.title, form.content, form.mood);
      navigate(`/entry/${entry.id}`);
    }, 400);
  };

  return (
    <div className="entry-form-page page-wrapper">
      <div className="entry-form-header fade-in">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>
        <h1 className="entry-form-title">New entry</h1>
      </div>

      <div className="entry-form-layout">
        <form className="entry-form fade-in" onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Title</label>
            <input
              type="text"
              className="form-input"
              placeholder="What's on your mind today?"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Mood</label>
            <div className="mood-picker">
              {MOODS.map(m => (
                <button
                  key={m}
                  type="button"
                  className={`mood-option ${form.mood === m ? 'selected' : ''}`}
                  onClick={() => setForm({ ...form, mood: m })}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">
              Your thoughts
              <span className="word-count">{form.content.split(/\s+/).filter(Boolean).length} words</span>
            </label>
            <textarea
              className="form-textarea"
              placeholder="Write freely. This is your safe space..."
              value={form.content}
              onChange={e => setForm({ ...form, content: e.target.value })}
              rows={14}
              required
            />
          </div>

          <div className="form-actions">
            <button type="button" className="cancel-btn" onClick={() => navigate(-1)}>
              Cancel
            </button>
            <button type="submit" className="save-btn" disabled={saving}>
              {saving ? 'Saving...' : 'Save entry'}
            </button>
          </div>
        </form>

        <aside className="entry-sidebar fade-in" style={{ animationDelay: '0.1s' }}>
          <div className="sidebar-card">
            <h3 className="sidebar-title">Live sentiment preview</h3>
            {preview ? (
              <div className="sentiment-preview">
                <div
                  className="sentiment-preview__badge"
                  style={{ color: getSentimentColor(preview.label) }}
                >
                  <span className="sentiment-preview__icon">{getSentimentEmoji(preview.label)}</span>
                  <span className="sentiment-preview__label">{preview.label}</span>
                </div>
                <div className="sentiment-preview__score">
                  Score: <strong>{preview.score > 0 ? '+' : ''}{preview.score}</strong>
                </div>
                <div className="sentiment-preview__confidence">
                  Confidence: <strong>{Math.round(preview.confidence * 100)}%</strong>
                </div>
                <div className="sentiment-preview__breakdown">
                  <span className="pos-count">✦ {preview.positiveCount} positive</span>
                  <span className="neg-count">◆ {preview.negativeCount} negative</span>
                </div>
              </div>
            ) : (
              <p className="sidebar-hint">Start writing to see your sentiment analysis in real time.</p>
            )}
          </div>

          <div className="sidebar-card">
            <h3 className="sidebar-title">Writing tips</h3>
            <ul className="tips-list">
              <li>Write without judgment — this is your space</li>
              <li>Try to include how specific events made you feel</li>
              <li>Even a few sentences count</li>
              <li>Consistency matters more than length</li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default NewEntry;
