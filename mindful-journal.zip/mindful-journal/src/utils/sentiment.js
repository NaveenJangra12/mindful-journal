const POSITIVE_WORDS = [
  'happy','joy','wonderful','great','amazing','love','excellent','fantastic',
  'good','beautiful','grateful','blessed','excited','hope','peaceful','calm',
  'proud','success','achieve','smile','laugh','fun','enjoy','pleasure','delight',
  'inspired','motivated','confident','strong','fulfilled','content','positive',
  'incredible','awesome','brilliant','perfect','thrilled','elated','cheerful',
  'optimistic','refreshed','energized','grateful','thankful','appreciated'
];

const NEGATIVE_WORDS = [
  'sad','angry','terrible','awful','bad','hate','horrible','depressed','anxious',
  'worried','fear','pain','hurt','lonely','lost','confused','stressed','tired',
  'exhausted','hopeless','miserable','frustrated','disappointed','failed','cry',
  'crying','upset','overwhelmed','nervous','scared','guilty','ashamed','regret',
  'worthless','helpless','empty','numb','broken','struggling','difficult','hard',
  'suffering','grief','despair','trapped','stuck','irritated','annoyed'
];

const INTENSIFIERS = ['very','really','extremely','absolutely','completely','totally','so'];
const NEGATORS = ['not','never','no','nothing','nobody','none','without'];

export const analyzeSentiment = (text) => {
  if (!text || text.trim().length === 0) {
    return { label: 'neutral', score: 0, confidence: 0.5 };
  }

  const words = text.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/);
  let score = 0;
  let total = 0;

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const prev = words[i - 1] || '';
    const prevPrev = words[i - 2] || '';
    const isNegated = NEGATORS.includes(prev) || NEGATORS.includes(prevPrev);
    const isIntensified = INTENSIFIERS.includes(prev);
    const multiplier = isIntensified ? 1.5 : 1;

    if (POSITIVE_WORDS.includes(word)) {
      score += isNegated ? -1 * multiplier : 1 * multiplier;
      total++;
    } else if (NEGATIVE_WORDS.includes(word)) {
      score += isNegated ? 1 * multiplier : -1 * multiplier;
      total++;
    }
  }

  const wordCount = words.length;
  const normalizedScore = total > 0 ? score / Math.max(total, wordCount * 0.1) : 0;
  const clampedScore = Math.max(-1, Math.min(1, normalizedScore));
  const confidence = Math.min(0.95, 0.5 + Math.abs(clampedScore) * 0.4 + (total / wordCount) * 0.1);

  let label;
  if (clampedScore > 0.15) label = 'positive';
  else if (clampedScore < -0.15) label = 'negative';
  else label = 'neutral';

  return {
    label,
    score: Math.round(clampedScore * 100) / 100,
    confidence: Math.round(confidence * 100) / 100,
    positiveCount: words.filter(w => POSITIVE_WORDS.includes(w)).length,
    negativeCount: words.filter(w => NEGATIVE_WORDS.includes(w)).length,
    wordCount
  };
};

export const getSentimentColor = (label) => {
  if (label === 'positive') return 'var(--positive)';
  if (label === 'negative') return 'var(--negative)';
  return 'var(--neutral)';
};

export const getSentimentBg = (label) => {
  if (label === 'positive') return 'var(--positive-dim)';
  if (label === 'negative') return 'var(--negative-dim)';
  return 'var(--neutral-dim)';
};

export const getSentimentEmoji = (label) => {
  if (label === 'positive') return '✦';
  if (label === 'negative') return '◆';
  return '◇';
};

export const seedDemoData = (userId) => {
  const existing = localStorage.getItem(`mj_entries_${userId}`);
  if (existing && JSON.parse(existing).length > 0) return;

  const demos = [
    { title: 'A fresh start', content: 'Today was wonderful. I felt so grateful and happy for everything around me. The morning light was beautiful and I felt truly blessed to be alive.', mood: '😊', daysAgo: 0 },
    { title: 'Feeling anxious', content: 'I am really worried and stressed about the upcoming deadline. I feel overwhelmed and exhausted. It is hard to focus and I feel lost sometimes.', mood: '😟', daysAgo: 1 },
    { title: 'Quiet afternoon', content: 'Spent the afternoon reading. Nothing particularly exciting happened today. Just went about my usual routine and had dinner at home.', mood: '😐', daysAgo: 2 },
    { title: 'Great news!', content: 'I received amazing news today! I feel so excited and proud. This is a fantastic achievement and I am incredibly motivated to keep going forward.', mood: '🎉', daysAgo: 3 },
    { title: 'Tough day', content: 'Feeling very tired and frustrated. The day was difficult and nothing seemed to go right. I feel a bit hopeless and sad tonight.', mood: '😔', daysAgo: 4 },
    { title: 'Morning walk', content: 'Had a peaceful morning walk in the park. Feeling calm and refreshed. The fresh air was good and I felt a quiet sense of contentment.', mood: '🌿', daysAgo: 5 },
    { title: 'Creative flow', content: 'I had an incredibly inspired and energized day. Everything felt brilliant and I was completely absorbed in my work. Feeling fulfilled and strong.', mood: '✨', daysAgo: 6 },
  ];

  const entries = demos.map((d, i) => {
    const date = new Date();
    date.setDate(date.getDate() - d.daysAgo);
    const sentiment = analyzeSentiment(d.content);
    return {
      id: `demo_${i}`,
      title: d.title,
      content: d.content,
      mood: d.mood,
      sentiment,
      createdAt: date.toISOString(),
      updatedAt: date.toISOString(),
    };
  });

  localStorage.setItem(`mj_entries_${userId}`, JSON.stringify(entries));
};
